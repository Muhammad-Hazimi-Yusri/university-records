LATEX
------ 
To compile a LaTEX report (Weekly_Report_Michael.tex) in Linux or Mac:

1) Run the pdflatex command     : >pdflatex Weekly_Report_Michael 
   [run twice]			: >pdflatex Weekly_Report_Michael

2) To generate the bibliography : >bibtex Weekly_Report_Michael
			        : >pdflatex Weekly_Report_Michael
   You need to update the file 'reference-file.bib' by inserting references into it using a proper format.


Brief intro can be found in:
---------------------------
http://www.maths.tcd.ie/~dwilkins/LaTeXPrimer/
https://www.overleaf.com/


Further details on Latex:
1) lshort2e-2pages.ps 
2) GSWLaTeX2.ps


